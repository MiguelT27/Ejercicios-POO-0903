/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema0703;

/**
 *
 * @author Estudiante
 */
public class Familia {
    private String Nombre;
    private Persona[] NucleoF;
    
    public Familia(String N, Persona[] Nu){
        Nombre = N;
        NucleoF = Nu;
    }       //Constructor

    public String getNombre() {
        return Nombre;
    }                   //Getter Nombre
    public Persona[] getNucleoF() {
        return NucleoF;
    }               //Getter Vector de personas integrantes del Nucleo Familiar
    
    

}
