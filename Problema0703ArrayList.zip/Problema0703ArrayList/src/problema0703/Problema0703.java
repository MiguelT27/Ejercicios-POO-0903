/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema0703;

/**
 *
 * @author Estudiante
 */
public class Problema0703 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.util.Scanner lectura = new java.util.Scanner(System.in);
        String Nombre, Apellido, Rol, Sexo;
        String NombreFa = " ";
        int Edad;
        Persona P1, P2, P3, P4;
        Familia F1, F2, F3, F4, F5;
        Persona[] Fa = new Persona[4];
        Familia[] ListaFa = new Familia[5];
        //System.out.print("Ingrese los datos de la familia: ");
        for (int i = 1; i <= 5; i++){
            System.out.println("INFORMACION FAMILIA No."+i);
            System.out.println();
            for(int j = 1; j <= 4; j++){
                System.out.print("INGRESE EL ROL DEL FAMILIAR No."+j);
                System.out.print(": ");
                Rol = lectura.next();
                System.out.println();
                switch(Rol){
                    case "PADRE":
                        System.out.print("      Ingrese el nombre del padre: ");
                        Nombre = lectura.next();
                        System.out.print("      Ingrese el apellido del padre: ");
                        Apellido = lectura.next();
                        Sexo = "Masculino";
                        System.out.print("      Ingrese la edad del padre: ");
                        Edad = lectura.nextInt();
                        P1 = new Persona (Nombre, Apellido,Edad, Sexo, Rol);
                        Fa[0] = P1;
                        NombreFa = Apellido;
                        System.out.println();
                        break;
                    case "MADRE":
                        System.out.print("      Ingrese el nombre de la madre: ");
                        Nombre = lectura.next();
                        System.out.print("      Ingrese el apellido de la madre: ");
                        Apellido = lectura.next();
                        Sexo = "Femenino";
                        System.out.print("      Ingrese la edad de la madre: ");
                        Edad = lectura.nextInt();
                        P2 = new Persona (Nombre, Apellido,Edad, Sexo, Rol);
                        Fa[1] = P2;
                        System.out.println();
                        break;
                    case "HIJO1":
                        System.out.print("      Ingrese el nombre del primer Hijo: ");
                        Nombre = lectura.next();
                        System.out.print("      Ingrese el apellido del primer Hijo: ");
                        Apellido = lectura.next();
                        System.out.print("      Ingrese el sexo del primer Hijo: ");
                        Sexo = lectura.next();
                        System.out.print("      Ingrese la edad del primer Hijo: ");
                        Edad = lectura.nextInt();
                        P3 = new Persona (Nombre, Apellido,Edad, Sexo, Rol);
                        Fa[2] = P3;
                        System.out.println();
                        break;
                    case "HIJO2":
                        System.out.print("      Ingrese el nombre del segundo Hijo: ");
                        Nombre = lectura.next();
                        System.out.print("      Ingrese el apellido del segundo Hijo: ");
                        Apellido = lectura.next();
                        System.out.print("      Ingrese el sexo del segundo Hijo: ");
                        Sexo = lectura.next();
                        System.out.print("      Ingrese la edad del segundo Hijo: ");
                        Edad = lectura.nextInt();
                        P4 = new Persona (Nombre, Apellido,Edad, Sexo, Rol);
                        Fa[3] = P4;
                        System.out.println();
                        break;
                } 
            }
            switch(i){
                case 1:
                    F1 = new Familia(NombreFa, Fa);
                    ListaFa[0] = F1;
                    break;
                case 2:
                    F2 = new Familia(NombreFa, Fa);
                    ListaFa[1] = F2;
                    break;
                case 3:
                    F3 = new Familia(NombreFa, Fa);
                    ListaFa[2] = F3;
                    break;
                case 4:
                    F4 = new Familia(NombreFa, Fa);
                    ListaFa[3] = F4;
                    break;
                case 5:
                    F5 = new Familia(NombreFa, Fa);
                    ListaFa[4] = F5;
                    break;
            }  
        }
        String Respuesta;
        do{
            System.out.print("DESEA CONSULTAR LA INFORMACION DE ALGUNA FAMILIA(S/N): ");
            System.out.println();
            Respuesta = lectura.next();

            if(Respuesta.equals("S") || Respuesta.equals("s")){
                System.out.print("      Ingrese el nombre de la familia: ");
                NombreFa = lectura.next();
                for(int i = 0; i < 5; i++){
                    if(ListaFa[i].getNombre().equals(NombreFa)){
                        Familia Fam = new Familia(NombreFa, ListaFa[i].getNucleoF());
                        ConsultarFamilia(NombreFa, ListaFa);
                    }
                }
                System.out.println();
                
            }
        }while(Respuesta.equals("S") || Respuesta.equals("s"));
    }
    public static void ConsultarFamilia(String NombreFa, Familia[] ListaFa){
        java.util.Scanner lectura = new java.util.Scanner(System.in);
        int i = 0;
        boolean bandera = true;
        while(i < 5 && bandera == true){
            if(ListaFa[i].getNombre().equals(NombreFa) == true){
                bandera = false;
            }
            i++;
        }
        i--;
        
        System.out.print("LA FAMILIA "+NombreFa);
        System.out.println(" ESTA COMPUESTA POR: ");
        System.out.println();
        for(int j = 0; j < 4; j++){
            switch (j){
                case 0:
                    System.out.println("PADRE");
                    System.out.println("        Nombre: "+ListaFa[i].getNucleoF()[0].getNombre());
                    System.out.println("        Apellido: "+ListaFa[i].getNucleoF()[0].getApellido());
                    System.out.println("        Edad: "+ListaFa[i].getNucleoF()[0].getEdad());
                    System.out.println("        Sexo: "+ListaFa[i].getNucleoF()[0].getSexo());
                    System.out.println();
                    break;
                case 1:
                    System.out.println("MADRE");
                    System.out.println("        Nombre: "+ListaFa[i].getNucleoF()[1].getNombre());
                    System.out.println("        Apellido: "+ListaFa[i].getNucleoF()[1].getApellido());
                    System.out.println("        Edad: "+ListaFa[i].getNucleoF()[1].getEdad());
                    System.out.println("        Sexo: "+ListaFa[i].getNucleoF()[1].getSexo());
                    System.out.println();
                    break;
                case 2:
                    System.out.println("HIJO 1");
                    System.out.println("        Nombre: "+ListaFa[i].getNucleoF()[2].getNombre());
                    System.out.println("        Apellido: "+ListaFa[i].getNucleoF()[2].getApellido());
                    System.out.println("        Edad: "+ListaFa[i].getNucleoF()[2].getEdad());
                    System.out.println("        Sexo: "+ListaFa[i].getNucleoF()[2].getSexo());
                    System.out.println();
                    break;
                case 3:
                    System.out.println("HIJO 2");
                    System.out.println("        Nombre: "+ListaFa[i].getNucleoF()[3].getNombre());
                    System.out.println("        Apellido: "+ListaFa[i].getNucleoF()[3].getApellido());
                    System.out.println("        Edad: "+ListaFa[i].getNucleoF()[3].getEdad());
                    System.out.println("        Sexo: "+ListaFa[i].getNucleoF()[3].getSexo());
                    System.out.println();
                    break;
            }
        }
        String Respuesta;
        do{
            System.out.print("DESEA CONSULTAR LA INFORMACION DE ALGUN MIEMBRO DE LA FAMILIA(S/N): ");
            System.out.println();
            Respuesta = lectura.next();
            if(Respuesta.equals("S") || Respuesta.equals("s")){
                System.out.print("      Ingrese el rol del integrante: ");
                String Rol = lectura.next(); 
                System.out.println();
                ConsultarMiembro(Rol, ListaFa, i);
            }
        }while(Respuesta.equals("S") || Respuesta.equals("s"));  
    }
    public static void ConsultarMiembro(String Rol, Familia[] ListaFa, int NoFamilia){
        switch (Rol){
                case "PADRE":
                    System.out.println("PADRE");
                    System.out.println("        Nombre: "+ListaFa[NoFamilia].getNucleoF()[0].getNombre());
                    System.out.println("        Apellido: "+ListaFa[NoFamilia].getNucleoF()[0].getApellido());
                    System.out.println("        Edad: "+ListaFa[NoFamilia].getNucleoF()[0].getEdad());
                    System.out.println("        Sexo: "+ListaFa[NoFamilia].getNucleoF()[0].getSexo());
                    System.out.println();
                    
                    System.out.print("      SU ESPOSA ES "+ListaFa[NoFamilia].getNucleoF()[1].getNombre());
                    System.out.print(" "+ListaFa[NoFamilia].getNucleoF()[1].getApellido());
                    System.out.print("CON "+ListaFa[NoFamilia].getNucleoF()[1].getEdad());
                    System.out.println(" AÑOS.");
                    
                    System.out.print("      SUS HIJOS SON "+ListaFa[NoFamilia].getNucleoF()[2].getNombre());
                    System.out.print(" "+ListaFa[NoFamilia].getNucleoF()[2].getApellido());
                    System.out.print("Y "+ListaFa[NoFamilia].getNucleoF()[3].getNombre());
                    System.out.println(" "+ListaFa[NoFamilia].getNucleoF()[3].getApellido());
                    System.out.print("      CON "+ListaFa[NoFamilia].getNucleoF()[2].getEdad());
                    System.out.print("Y "+ListaFa[NoFamilia].getNucleoF()[3].getEdad());
                    System.out.println("RESPECTIVAMENTE.");
                    System.out.println();

                    break;
                    
                case "MADRE":
                    System.out.println("MADRE");
                    System.out.println("        Nombre: ");
                    System.out.println("        Apellido: "+ListaFa[NoFamilia].getNucleoF()[1].getApellido());
                    System.out.println("        Edad: "+ListaFa[NoFamilia].getNucleoF()[1].getEdad());
                    System.out.println("        Sexo: "+ListaFa[NoFamilia].getNucleoF()[1].getSexo());
                    System.out.println();
                    
                    System.out.print("      SU ESPOSO ES "+ListaFa[NoFamilia].getNucleoF()[0].getNombre());
                    System.out.print(" "+ListaFa[NoFamilia].getNucleoF()[0].getApellido());
                    System.out.print("CON "+ListaFa[NoFamilia].getNucleoF()[0].getEdad());
                    System.out.println(" AÑOS.");
                    
                    System.out.print("      SUS HIJOS SON "+ListaFa[NoFamilia].getNucleoF()[2].getNombre());
                    System.out.print(" "+ListaFa[NoFamilia].getNucleoF()[2].getApellido());
                    System.out.print("Y "+ListaFa[NoFamilia].getNucleoF()[3].getNombre());
                    System.out.println(" "+ListaFa[NoFamilia].getNucleoF()[3].getApellido());
                    System.out.print("      CON "+ListaFa[NoFamilia].getNucleoF()[2].getEdad());
                    System.out.print("Y "+ListaFa[NoFamilia].getNucleoF()[3].getEdad());
                    System.out.println("RESPECTIVAMENTE.");
                    System.out.println();
                    break;
                case "HIJO1":
                    System.out.println("HIJO 1");
                    System.out.println("        Nombre: "+ListaFa[NoFamilia].getNucleoF()[2].getNombre());
                    System.out.println("        Apellido: "+ListaFa[NoFamilia].getNucleoF()[2].getApellido());
                    System.out.println("        Edad: "+ListaFa[NoFamilia].getNucleoF()[2].getEdad());
                    System.out.println("        Sexo: "+ListaFa[NoFamilia].getNucleoF()[2].getSexo());
                    System.out.println();
                    
                    System.out.print("      SU PADRE ES "+ListaFa[NoFamilia].getNucleoF()[0].getNombre());
                    System.out.print(" "+ListaFa[NoFamilia].getNucleoF()[0].getApellido());
                    System.out.print("Y SU MADRE ES "+ListaFa[NoFamilia].getNucleoF()[1].getNombre());
                    System.out.println(" "+ListaFa[NoFamilia].getNucleoF()[1].getApellido());
                    System.out.print("      CON "+ListaFa[NoFamilia].getNucleoF()[0].getEdad());
                    System.out.print("Y "+ListaFa[NoFamilia].getNucleoF()[1].getEdad());
                    System.out.println("RESPECTIVAMENTE.");
                    System.out.println();
                    
                    System.out.print("      SU HERMANO/A ES "+ListaFa[NoFamilia].getNucleoF()[3].getNombre());
                    System.out.print(" "+ListaFa[NoFamilia].getNucleoF()[3].getApellido());
                    System.out.print("CON "+ListaFa[NoFamilia].getNucleoF()[3].getEdad());
                    System.out.println(" AÑOS.");
                    
                    break;
                case "HIJO2":
                    System.out.println("HIJO 2");
                    System.out.println("        Nombre: "+ListaFa[NoFamilia].getNucleoF()[3].getNombre());
                    System.out.println("        Apellido: "+ListaFa[NoFamilia].getNucleoF()[3].getApellido());
                    System.out.println("        Edad: "+ListaFa[NoFamilia].getNucleoF()[3].getEdad());
                    System.out.println("        Sexo: "+ListaFa[NoFamilia].getNucleoF()[3].getSexo());
                    System.out.println();
                    
                    System.out.print("      SU PADRE ES "+ListaFa[NoFamilia].getNucleoF()[0].getNombre());
                    System.out.print(" "+ListaFa[NoFamilia].getNucleoF()[0].getApellido());
                    System.out.print("Y SU MADRE ES "+ListaFa[NoFamilia].getNucleoF()[1].getNombre());
                    System.out.println(" "+ListaFa[NoFamilia].getNucleoF()[1].getApellido());
                    System.out.print("      CON "+ListaFa[NoFamilia].getNucleoF()[0].getEdad());
                    System.out.print("Y "+ListaFa[NoFamilia].getNucleoF()[1].getEdad());
                    System.out.println("RESPECTIVAMENTE.");
                    System.out.println();
                    
                    System.out.print("      SU HERMANO/A ES "+ListaFa[NoFamilia].getNucleoF()[2].getNombre());
                    System.out.print(" "+ListaFa[NoFamilia].getNucleoF()[2].getApellido());
                    System.out.print("CON "+ListaFa[NoFamilia].getNucleoF()[2].getEdad());
                    System.out.println(" AÑOS.");
                    break;
            }
    }
    
}
