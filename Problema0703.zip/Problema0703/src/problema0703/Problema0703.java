package problema0703;
import java.util.*;
/*
 * @Miguel Tapiero
 */
public class Problema0703 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        java.util.Scanner lectura = new java.util.Scanner(System.in);
        String Nombre, Apellido, Rol, Sexo;
        int Edad;
        String NombreFa;
        int NoFamilias, NoIntegrantes;
        Persona P;
        ArrayList<Persona> Fa = new ArrayList();
        ArrayList<Familia> ListaFa = new ArrayList();
        System.out.print("NUMERO DE FAMILIAS A REGISTRAR: ");
        NoFamilias = lectura.nextInt();
        System.out.println();
        for (int i = 1; i <= NoFamilias; i++){
            System.out.println("INFORMACION FAMILIA No."+i);
            System.out.println();
            System.out.print("    NUMERO DE INTEGRANTES:");
            NoIntegrantes = lectura.nextInt();
            System.out.print("    NOMBRE DE LA FAMILIA:");
            NombreFa = lectura.next();
            System.out.println();
            for(int j = 1; j <= NoIntegrantes; j++){
                System.out.print("    INGRESE EL ROL DEL FAMILIAR No."+j);
                System.out.print(": ");
                Rol = lectura.next();
                System.out.println();
                System.out.print("      NOMBRE: ");
                Nombre = lectura.next();
                System.out.print("      APELLIDO: ");
                Apellido = lectura.next();
                System.out.print("      SEXO(M/F): ");
                Sexo = lectura.next();
                System.out.print("      EDAD: ");
                Edad = lectura.nextInt();
                P =  new Persona (Nombre, Apellido, Edad, Sexo, Rol);
                Fa.add(P);
                System.out.println();
                if(j == NoIntegrantes){
                    Familia F = new Familia(NombreFa, Fa);
                    ListaFa.add(F);
                }
            }
        }
        String Respuesta;
        do{
            System.out.print("DESEA CONSULTAR LA INFORMACION DE ALGUNA FAMILIA(S/N): ");
            Respuesta = lectura.next();
            System.out.println();
            if( Respuesta.equals("S") || Respuesta.equals("s") ){
                System.out.print("      INGRESE EL NOMBRE DE LA FAMILIA: ");
                NombreFa = lectura.next();
                for(int i = 0; i < ListaFa.size(); i++){
                    if(ListaFa.get(i).getNombre().equals(NombreFa)){
                        Familia Fam = ListaFa.get(i);
                        ConsultarFamilia(Fam);
                    }
                }
                System.out.println();
            }
        }while(Respuesta.equals("S") || Respuesta.equals("s"));
    }
    public static void ConsultarFamilia(Familia F){
        java.util.Scanner lectura = new java.util.Scanner(System.in);
        System.out.println();
        System.out.print("        LA FAMILIA "+F.getNombre());
        System.out.println(" ESTA COMPUESTA POR: ");
        System.out.println();
        int t = F.getNucleoF().size();
        ;
        for(int j = 0; j < F.getNucleoF().size(); j++){
            System.out.println("        ROL: "+F.getNucleoF().get(j).getRol());
            System.out.println("          Nombre: "+F.getNucleoF().get(j).getNombre());
            System.out.println("          Apellido: "+F.getNucleoF().get(j).getApellido());
            System.out.println("          Edad: "+F.getNucleoF().get(j).getEdad());
            System.out.println("          Sexo: "+F.getNucleoF().get(j).getSexo());
            System.out.println();
        }
        String Respuesta, Rol;
        do{
            System.out.print("DESEA CONSULTAR LA INFORMACION DE ALGUN MIEMBRO DE LA FAMILIA "+F.getNombre());
            System.out.print(" (S/N): ");
            Respuesta = lectura.next();
            System.out.println();
            if(Respuesta.equals("S") || Respuesta.equals("s")){
                System.out.print("      INGRESE EL ROL DEL INTEGRANTE: ");
                Rol = lectura.next(); 
                System.out.println();
                ConsultarMiembro(Rol, F);
            }
        }while(Respuesta.equals("S") || Respuesta.equals("s"));  
    }
    public static void ConsultarMiembro(String Rol, Familia F){
        for (int i = 0; i < F.getNucleoF().size(); i++) {
            if (F.getNucleoF().get(i).getRol().equals(Rol)) {
                Persona P = F.getNucleoF().get(i);
                System.out.println("        Nombre: "+P.getNombre());
                System.out.println("        Apellido: "+P.getApellido());
                System.out.println("        Edad: "+P.getEdad());
                System.out.println("        Sexo: "+P.getSexo());
                System.out.println();
            }
        }
    }
}
