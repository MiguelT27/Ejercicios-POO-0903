/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema0703;
import java.util.*;

/**
 *
 * @author Estudiante
 */
public class Familia {
    private String Nombre;
    private ArrayList<Persona> NucleoF;
    
    public Familia(String N, ArrayList<Persona> Nu){
        Nombre = N;
        NucleoF = Nu;
    }     
    public String getNombre() {
        return Nombre;
    }
    public ArrayList<Persona> getNucleoF() {
        return NucleoF;
    }
}
