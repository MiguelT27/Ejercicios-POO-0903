/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema0703;
import java.util.*;
/**
 *
 * @author Estudiante
 */
public class RegistroFamilias {
    private ArrayList<Familia> Lista;

    public RegistroFamilias(ArrayList<Familia> L) {
        Lista = L;
    }

    public ArrayList<Familia> getLista() {
        return Lista;
    }
    
    
}
