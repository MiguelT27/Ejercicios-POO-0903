/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package problema0703;

/**
 *
 * @author Estudiante
 */
public class Persona {
    private String Nombre;
    private String Apellido;
    private int Edad;
    private String Sexo;
    private String Rol;

    public Persona (String N, String A, int E, String S, String R){
        Nombre = N;
        Apellido = A;
        Edad = E;
        Sexo = S;
        Rol = R;
    }

    public String getNombre() {
        return Nombre;
    }
    public String getApellido() {
        return Apellido;
    }
    public int getEdad() {
        return Edad;
    }
    public String getSexo() {
        return Sexo;
    }
    public String getRol() {
        return Rol;
    }
    
    
    
}
